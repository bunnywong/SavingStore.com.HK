<?php
// Text
$_['text_title']                = '英國皇家郵政';
$_['text_weight']               = '重量:';
$_['text_insurance']            = 'Insured upto:';
$_['text_eta']                  = 'Estimated Time:';
$_['text_1st_class_standard']   = 'First Class Standard Post';
$_['text_1st_class_recorded']   = 'First Class Recorded Post';
$_['text_2nd_class_standard']   = 'Second Class Standard Post';
$_['text_2nd_class_recorded']   = 'Second Class Recorded Post';
$_['text_special_delivery_500']  = 'Special Delivery Next Day (&pound;500)';
$_['text_special_delivery_1000'] = 'Special Delivery Next Day (&pound;1000)';
$_['text_special_delivery_2500'] = 'Special Delivery Next Day (&pound;2500)';
$_['text_standard_parcels']     = '標準包裹';
$_['text_airmail']              = 'Airmail';
$_['text_international_signed'] = 'International Signed';
$_['text_airsure']              = 'Airsure';
$_['text_surface']              = 'Surface';
?>