<?php
// Text
$_['text_title']       = '自取或面交';
$_['text_description'] = '到本商店自取或見面交收';
?>