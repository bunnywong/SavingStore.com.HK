<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Express';
$_['text_standard'] = '標準';
$_['text_eta']      = 'days';
?>