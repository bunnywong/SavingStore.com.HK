<?php
// Text
$_['text_title']       = '按每件計運費';
$_['text_description'] = '按每件計運費率';
?>