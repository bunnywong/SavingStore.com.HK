<?php
// Heading
$_['heading_title']     = '系統維護';

// Text
$_['text_maintenance']  = '系統維護';
$_['text_message']      = '<h1 style="text-align:center;">現在我們正在進行系統維護。 <br/>我們將很快結束本次維護，請稍後再訪問本站。</h1>';
?>