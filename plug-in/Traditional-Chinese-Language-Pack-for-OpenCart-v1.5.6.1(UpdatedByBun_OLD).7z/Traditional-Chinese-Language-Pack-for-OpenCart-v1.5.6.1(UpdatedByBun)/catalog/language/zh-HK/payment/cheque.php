<?php
// Text
$_['text_title']       = '支票 / 匯票指令';
$_['text_instruction'] = '支票 / 匯票付款說明';
$_['text_payable']     = '款項匯至︰ ';
$_['text_address']     = '發送到︰ ';
$_['text_payment']     = '收到付款後我們將按照您的訂單發貨。';
?>