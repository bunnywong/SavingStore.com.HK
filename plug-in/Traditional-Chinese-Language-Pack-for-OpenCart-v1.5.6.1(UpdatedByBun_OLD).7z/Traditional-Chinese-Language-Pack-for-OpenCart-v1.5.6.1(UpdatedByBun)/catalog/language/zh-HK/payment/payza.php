<?php
// Text
$_['text_title'] = '信用卡或扣賬卡 (Payza)';
?>