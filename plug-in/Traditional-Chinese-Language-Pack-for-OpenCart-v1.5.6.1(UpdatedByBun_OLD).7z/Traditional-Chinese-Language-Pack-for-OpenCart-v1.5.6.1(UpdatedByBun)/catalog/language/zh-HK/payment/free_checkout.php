<?php
// Text
$_['text_title'] = '免費結帳';
?>