<?php
// Text
$_['text_title']           = '信用卡 / 扣賬卡(Web Payment Software)';
$_['text_credit_card']     = '信用卡資料';
$_['text_wait']            = '請稍候！';

// Entry
$_['entry_cc_owner']       = '持卡人︰';
$_['entry_cc_number']      = '卡號︰';
$_['entry_cc_expire_date'] = '信用卡有效期到︰';
$_['entry_cc_cvv2']        = '信用卡安全碼 (CVV2)︰';
?>