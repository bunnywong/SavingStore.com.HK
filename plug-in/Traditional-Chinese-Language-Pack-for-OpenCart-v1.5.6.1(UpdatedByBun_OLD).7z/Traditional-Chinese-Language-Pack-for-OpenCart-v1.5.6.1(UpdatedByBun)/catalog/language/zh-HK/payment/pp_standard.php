<?php
// Text
$_['text_title'] 	= 'PayPal';
$_['text_reason'] 	= '原因';
$_['text_testmode']	= 'Warning: The Payment Gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['text_total']	= '貨運, 手續費, 折扣及稅金';
?>