<?php

// Text
$_['text_title'] = '信用卡或扣賬卡 PAYFLOW';
$_['text_secure_connection'] = '正在創建一個安全的連接...';

$_['error_connection'] = "無法連接到PayPal。請聯絡店鋪的管理員尋求幫助，或選擇不同的付款方式。";