<?php
// Text
$_['text_title']       = '銀行轉帳';
$_['text_instruction'] = '銀行轉帳指令:';
$_['text_description'] = '請將訂單總額轉賬到以下銀行賬戶。';
$_['text_payment']     = '收到付款後我們將按訂單給您發貨。';
?>