<?php
// Text
$_['text_title'] = '信用卡 / 扣賬卡 (PayJunction)';
?>