<?php
// Text
$_['text_title']       = '信用卡 / 扣賬卡 (SagePay)';
$_['text_description'] = 'Items on %s 訂單號: %s';
?>