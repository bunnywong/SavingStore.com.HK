<?php
// Text
$_['text_title'] = '貨到付款';
?>