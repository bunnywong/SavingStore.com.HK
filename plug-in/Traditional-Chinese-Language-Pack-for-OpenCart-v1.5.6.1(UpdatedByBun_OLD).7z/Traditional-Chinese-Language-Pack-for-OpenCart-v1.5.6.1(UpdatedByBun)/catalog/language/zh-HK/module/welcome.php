<?php
$_['heading_title'] = '歡迎訪問 %s';
?>