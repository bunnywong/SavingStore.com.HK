<?php
// Heading 
$_['heading_title']  = '熱賣商品';

// Text
$_['text_reviews']     = '%s / 5 星！';
?>