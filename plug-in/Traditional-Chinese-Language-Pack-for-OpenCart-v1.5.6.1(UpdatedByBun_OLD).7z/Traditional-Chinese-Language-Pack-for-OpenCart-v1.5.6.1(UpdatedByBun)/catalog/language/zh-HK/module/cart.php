<?php
// Heading 
$_['heading_title'] = '購物車';

// Text
$_['text_items']    = '%s 項商品 - %s';
$_['text_empty']    = '您的購物車沒有添加商品！';
$_['text_cart']     = '查看購物車';
$_['text_checkout'] = '結算';

$_['text_payment_profile'] = '付款情況';
?>