<?php
// Heading 
$_['heading_title'] = '選擇商店';

// Text
$_['text_default']  = '默認';
$_['text_store']    = '請選擇您要瀏覽商店。';
?>