<?php
// Heading 
$_['heading_title']  = '特價商品';

// Text
$_['text_reviews']     = '%s / 5 星！';
?>