<?php
// Text
$_['text_currency'] = '貨幣';
?>