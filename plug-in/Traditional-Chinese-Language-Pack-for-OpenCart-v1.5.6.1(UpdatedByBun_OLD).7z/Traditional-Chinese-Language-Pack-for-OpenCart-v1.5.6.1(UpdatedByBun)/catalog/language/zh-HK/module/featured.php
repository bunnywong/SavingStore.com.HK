<?php
// Heading 
$_['heading_title']  = '特色商品';

// Text
$_['text_reviews']     = '%s / 5 星！';
?>