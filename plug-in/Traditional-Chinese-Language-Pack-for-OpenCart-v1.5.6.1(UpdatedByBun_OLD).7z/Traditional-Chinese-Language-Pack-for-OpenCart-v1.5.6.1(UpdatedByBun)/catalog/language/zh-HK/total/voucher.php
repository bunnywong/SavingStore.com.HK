<?php
// Heading 
$_['heading_title'] = '使用禮品券';

// Text
$_['text_voucher']  = '禮品券(%s)';
$_['text_success']  = '成功︰ 您的禮品券已經成功使用！';

// Entry
$_['entry_voucher'] = '請輸入您的禮品券代碼︰';

// Error
$_['error_voucher'] = '警告︰ 無效禮品券或此禮品券已經被使用！';
?>