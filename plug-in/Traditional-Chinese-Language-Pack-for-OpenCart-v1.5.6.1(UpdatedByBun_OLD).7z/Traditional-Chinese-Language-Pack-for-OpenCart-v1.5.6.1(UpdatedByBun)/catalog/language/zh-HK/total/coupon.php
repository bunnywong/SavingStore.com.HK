<?php
// Heading 
$_['heading_title'] = '使用優惠券';

// Text
$_['text_coupon']   = '優惠券(%s)';
$_['text_success']  = '成功︰ 您已成功使用優惠券！';

// Entry
$_['entry_coupon']  = '請輸入您的優惠券︰';

// Error
$_['error_coupon']  = '警告︰ 優惠券已失效，或已過期，或已超過其使用次數！';
?>