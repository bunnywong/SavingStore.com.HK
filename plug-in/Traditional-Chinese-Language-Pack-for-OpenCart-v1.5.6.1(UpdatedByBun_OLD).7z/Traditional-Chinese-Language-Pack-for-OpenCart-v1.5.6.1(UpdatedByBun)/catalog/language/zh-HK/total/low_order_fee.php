<?php
$_['text_low_order_fee'] = '小額訂單收費';
?>