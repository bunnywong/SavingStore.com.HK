<?php
$_['text_total'] = '訂單總額';
?>