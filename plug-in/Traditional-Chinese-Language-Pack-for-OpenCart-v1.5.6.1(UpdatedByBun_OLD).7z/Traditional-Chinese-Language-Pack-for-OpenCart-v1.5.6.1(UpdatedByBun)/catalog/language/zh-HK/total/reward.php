<?php
// Heading 
$_['heading_title'] = '使用獎勵積分 (有效 %s)';

// Text
$_['text_reward']   = '獎勵積分(%s)';
$_['text_order_id'] = '訂單號︰ #%s';
$_['text_success']  = '成功︰ 您已經成功使用了獎勵積分！';

// Entry
$_['entry_reward']  = '使用獎勵積分 (最多 %s)︰';

// Error
$_['error_empty']   = '警告︰ 請輸入您需要使用的獎勵積分數！';
$_['error_points']  = '警告︰ 您目前無可使用的獎勵積分%s！';
$_['error_maximum'] = '警告︰ 您可使用的最大獎勵積分數%s！';
?>