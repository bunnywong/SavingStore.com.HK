<?php
// Heading
$_['heading_title']    = '網站地圖';
 
// Text
$_['text_special']     = '特別優惠';
$_['text_account']     = '我的賬戶';
$_['text_edit']        = '賬戶信息';
$_['text_password']    = '更新密碼';
$_['text_address']     = '地址簿';
$_['text_history']     = '訂單記錄';
$_['text_download']    = '下載文件';
$_['text_cart']        = '購物車';
$_['text_checkout']    = '結賬';
$_['text_search']      = '搜索';
$_['text_information'] = '信息中心';
$_['text_contact']     = '聯絡我們';
?>
