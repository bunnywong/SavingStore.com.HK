<?php
$_['paid_on_amazonus_text'] = 'Amazon US 支付';
$_['shipping_text'] = '貨運';
$_['shipping_tax_text'] = '貨運稅率';
$_['gift_wrap_text'] = '包裝';
$_['gift_wrap_tax_text'] = '包裝稅率';
$_['sub_total_text'] = '小計';
$_['tax_text'] = '稅率';
$_['total_text'] = '總計'; 
?>