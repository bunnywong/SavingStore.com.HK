<?php
$_['title']         = 'OpenBay Pro 列表';
$_['help']          = '詳細說明';
?>