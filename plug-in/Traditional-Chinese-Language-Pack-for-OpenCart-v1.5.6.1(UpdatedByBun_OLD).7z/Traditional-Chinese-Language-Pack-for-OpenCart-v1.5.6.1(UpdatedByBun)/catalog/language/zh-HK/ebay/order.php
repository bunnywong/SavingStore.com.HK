<?php
$_['lang_shipping']     = '貨運';
$_['lang_discount']     = '折扣';
$_['lang_tax']          = '稅率';
$_['lang_subtotal']     = '小計';
$_['lang_total']        = '總計';
