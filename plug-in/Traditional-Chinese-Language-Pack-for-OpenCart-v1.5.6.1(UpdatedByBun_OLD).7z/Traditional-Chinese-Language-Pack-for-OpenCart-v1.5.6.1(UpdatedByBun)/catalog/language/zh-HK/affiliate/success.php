<?php
// Heading
$_['heading_title'] = '您的賬戶已建立！';

// Text
$_['text_approval'] = '<p>感謝您的註冊 %s！</p> <p>我們將會通過電子郵件給您發送一封賬戶激活郵件通知。</p><p>假如您對該網店操作有任何疑問， 請 <a href="%s">聯絡我們</a>。</p>';
$_['text_account']  = '我的賬戶';
$_['text_success']  = '註冊成功';
?>