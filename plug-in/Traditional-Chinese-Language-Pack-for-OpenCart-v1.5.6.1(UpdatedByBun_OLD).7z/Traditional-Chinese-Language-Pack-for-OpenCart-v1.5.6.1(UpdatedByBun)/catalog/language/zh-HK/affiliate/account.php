<?php
// Heading 
$_['heading_title']        = '我的加盟賬戶';

// Text
$_['text_account']         = '我的賬戶';
$_['text_my_account']      = '我的加盟賬戶';
$_['text_my_tracking']     = '我的跟蹤信息';
$_['text_my_transactions'] = '我的交易';
$_['text_edit']            = '編輯我的賬戶信息';
$_['text_password']        = '更改密碼';
$_['text_payment']         = '更改預設支付方式';
$_['text_tracking']        = '用戶跟蹤號';
$_['text_transaction']     = '查看我的交易記錄';
?>