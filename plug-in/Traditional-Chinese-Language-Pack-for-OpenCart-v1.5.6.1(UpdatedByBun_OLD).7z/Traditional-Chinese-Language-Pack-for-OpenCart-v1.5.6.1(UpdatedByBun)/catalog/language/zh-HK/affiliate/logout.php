<?php
// Heading 
$_['heading_title'] = '退出賬號';

// Text
$_['text_message']  = '<p>您已退出了您的賬戶。 可以安全離開電腦了。</p>';
$_['text_account']  = '賬號';
$_['text_logout']   = '退出';
?>