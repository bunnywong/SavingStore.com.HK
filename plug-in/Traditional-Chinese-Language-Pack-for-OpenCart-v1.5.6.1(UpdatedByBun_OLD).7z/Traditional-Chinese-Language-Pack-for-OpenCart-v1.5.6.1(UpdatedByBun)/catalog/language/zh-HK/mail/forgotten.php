<?php
// Text
$_['text_subject']  = '%s - 會員新密碼';
$_['text_greeting'] = '我們從 %s 收到您請求新的密碼，建議您在使用新密碼登入後立即變更此密碼，並妥善保存...';
$_['text_password'] = '您的新密碼︰';
?>