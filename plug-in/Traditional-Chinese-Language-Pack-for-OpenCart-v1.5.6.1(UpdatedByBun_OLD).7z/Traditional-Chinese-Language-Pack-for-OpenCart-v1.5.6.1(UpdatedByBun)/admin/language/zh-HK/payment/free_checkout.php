<?php
// Heading
$_['heading_title']      = '免費結帳';

// Text
$_['text_payment']       = '支付管理';
$_['text_success']       = '成功︰您已修改的免費結帳信息！';

// Entry
$_['entry_order_status'] = '訂單狀態︰';
$_['entry_status']       = '狀態︰';
$_['entry_sort_order']   = '排序︰';

// Error
$_['error_permission']   = '警告︰ 您沒有權限修改免費結賬支付！';
?>