<?php
$_['heading_title']             = '退款交易';

$_['text_pp_express']           = 'PayPal Express Checkout';
$_['text_current_refunds']      = '退款已經完成本次交易。最大的退款額為';

$_['btn_cancel']                = '取消退款';
$_['btn_refund']                = '發起退款';

$_['entry_transaction_id']      = '交易 ID';
$_['entry_full_refund']         = '全額退款';
$_['entry_amount']              = '金額';
$_['entry_message']             = '信息';

$_['error_partial_amt']         = '您必須輸入一個部分退款金額';
$_['error_data']                = 'Data missing from request';
?>