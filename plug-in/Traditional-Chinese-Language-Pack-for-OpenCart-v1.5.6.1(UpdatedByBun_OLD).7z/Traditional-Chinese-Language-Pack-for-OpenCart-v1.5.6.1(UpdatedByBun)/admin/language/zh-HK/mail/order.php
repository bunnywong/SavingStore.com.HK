<?php
// Text
$_['text_subject']      = '%s - 訂單更新通知 （訂單號︰ %s）';
$_['text_order']        = '訂單號︰';
$_['text_date_added']   = '日期排序︰';
$_['text_order_status'] = '您的訂單已更新為以下狀態︰';
$_['text_comment']      = '您的訂單附言︰';
$_['text_link']         = '要查看您的訂單，請點擊以下鏈接︰';
$_['text_footer']       = '如果您有任何疑問，請直接回復此郵件。';
?>