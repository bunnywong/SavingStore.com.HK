<?php
// Heading
$_['heading_title']     = '會員在線報告';

// Text 
$_['text_guest']        = '游客';
 
// Column
$_['column_ip']         = 'IP地址';
$_['column_customer']   = '會員';
$_['column_url']        = '最近瀏覽頁面';
$_['column_referer']    = '拓展自加盟會員';
$_['column_date_added'] = '最近訪問時間';
$_['column_action']     = '管理';
?>