<?php
// Heading
$_['heading_title']     = '會員加盟佣金統計';

// Column
$_['column_affiliate']  = '加盟會員名';
$_['column_email']      = 'E-Mail';
$_['column_status']     = '狀態';
$_['column_commission'] = '佣金';
$_['column_orders']     = '訂單數量';
$_['column_total']      = '佣金總計';
$_['column_action']     = '管理';

// Entry
$_['entry_date_start']  = '開始日期︰';
$_['entry_date_end']    = '結束日期︰';
?>