<?php
// Heading
$_['heading_title']    = '折扣統計報表';

// Column
$_['column_name']      = '折扣名稱';
$_['column_code']      = '折扣代碼';
$_['column_orders']    = '訂單';
$_['column_total']     = '合計';
$_['column_action']    = '管理';

// Entry
$_['entry_date_start']  = '開始日期︰';
$_['entry_date_end']    = '結束日期︰';
?>