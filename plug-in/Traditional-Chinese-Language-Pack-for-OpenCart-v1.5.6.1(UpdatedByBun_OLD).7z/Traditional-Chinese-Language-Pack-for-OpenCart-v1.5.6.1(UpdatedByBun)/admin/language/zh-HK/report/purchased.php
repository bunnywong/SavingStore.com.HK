<?php
// Heading
$_['heading_title']   = '商品購買報表';

// Column
$_['column_name']     = '商品名稱';
$_['column_model']    = '商品型號';
$_['column_quantity'] = '購買數量';
$_['column_total']    = '金額總計';
?>
