<?php
// Heading
$_['heading_title'] = '錯誤日誌 ';

// Text
$_['text_success']  = '成功︰您已成功清除錯誤日誌 ！';
?>