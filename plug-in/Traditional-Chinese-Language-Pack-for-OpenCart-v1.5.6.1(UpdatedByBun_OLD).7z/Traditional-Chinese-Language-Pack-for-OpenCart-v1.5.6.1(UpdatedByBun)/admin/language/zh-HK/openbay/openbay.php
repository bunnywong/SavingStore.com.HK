<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = '編輯';
$_['text_install']                      = '安裝';
$_['text_uninstall']                    = '卸載';
$_['text_enabled']                      = '啟用';
$_['text_disabled']                     = '停用';
$_['error_category_nosuggestions']      = '無法加載任何建議的類別';
$_['lang_text_success']                 = '您已經成功更改eBay擴展';
?>