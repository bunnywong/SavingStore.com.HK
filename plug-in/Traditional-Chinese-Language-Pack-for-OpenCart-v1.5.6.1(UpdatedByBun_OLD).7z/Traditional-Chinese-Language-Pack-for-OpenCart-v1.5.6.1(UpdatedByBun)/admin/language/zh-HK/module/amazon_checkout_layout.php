<?php
// Heading
$_['heading_title'] = '亞馬遜支付按鈕(Amazon Payments button)';

$_['text_module']         = '模組';
$_['text_success']        = '已成功修改亞馬遜支付按鈕(Amazon Payments button)模組設置';
$_['text_content_top']    = '內容的上面';
$_['text_content_bottom'] = '內容的底部';
$_['text_column_left']    = '左列顯示';
$_['text_column_right']   = '右列顯示';

$_['entry_layout']        = '布局';
$_['entry_position']   = '顯示位置';
$_['entry_status']     = '狀態';
$_['entry_sort_order'] = '排序';

$_['error_permission'] = '警告︰您沒有權限更改亞馬遜支付按鈕(Amazon Payments button)模組設置';
