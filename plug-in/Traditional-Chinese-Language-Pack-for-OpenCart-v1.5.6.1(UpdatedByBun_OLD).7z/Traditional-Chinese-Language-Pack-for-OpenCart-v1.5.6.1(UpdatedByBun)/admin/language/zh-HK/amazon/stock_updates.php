<?php
$_['lang_title']                    = 'OpenBay Pro for Amazon | 庫存更新';
$_['lang_stock_updates']            = '庫存更新';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_overview']                 = 'Amazon Overview';
$_['lang_my_account']               = '我的帳戶';
$_['lang_btn_return']               = '取消';
//Table columns
$_['lang_ref']                      = 'Ref';
$_['lang_date_requested']           = '申請日期';
$_['lang_date_updated']             = '更新日期';
$_['lang_status']                   = '狀態';
$_['lang_sku']                      = 'Amazon SKU';
$_['lang_stock']                    = '庫存';


$_['lang_empty']                    = '沒有結果！';
$_['lang_date_start']               = '開始日期︰';
$_['lang_date_end']                 = '結束日期︰';
$_['lang_filter_btn']               = '篩選';