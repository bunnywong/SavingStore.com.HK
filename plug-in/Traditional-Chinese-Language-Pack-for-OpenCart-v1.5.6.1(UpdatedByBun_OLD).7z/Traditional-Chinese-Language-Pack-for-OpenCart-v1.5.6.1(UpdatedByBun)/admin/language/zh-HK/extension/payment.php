<?php
// Heading
$_['heading_title']      = '支付管理';

// Text
$_['text_install']       = '安裝';
$_['text_uninstall']     = '卸載';

// Column
$_['column_name']        = '支付方式';
$_['column_status']      = '狀態';
$_['column_sort_order']  = '排序';
$_['column_action']      = '管理';

// Error
$_['error_permission']   = '警告︰ 您沒有權限修改支付管理！';
?>