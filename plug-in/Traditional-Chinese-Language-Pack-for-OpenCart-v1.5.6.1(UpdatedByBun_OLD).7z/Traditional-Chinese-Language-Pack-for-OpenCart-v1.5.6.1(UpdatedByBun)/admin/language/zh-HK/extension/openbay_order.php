<?php
$_['lang_btn_status']           = '改變訂單狀態';
$_['lang_order_channel']        = '訂單來源';
$_['lang_confirmed']            = '個已標記訂單更新為';
$_['lang_no_orders']            = '未選擇要更新的訂單';
$_['lang_confirm_title']        = '訂單狀態批量更新預覽';
$_['lang_confirm_change_text']  = '將訂單狀態改變為';
$_['lang_column_addtional']     = '附加信息';
$_['lang_column_comments']      = '備註';
$_['lang_column_notify']        = '通知';
$_['lang_carrier']              = '貨運者';
$_['lang_tracking']             = '跟蹤';
$_['lang_other']                = '其他';
$_['lang_refund_reason']        = '退款原因';
$_['lang_refund_message']       = '退款消息';
$_['lang_update']               = '確認更新';
$_['lang_cancel']               = '取消';
$_['lang_e_ajax_1']             = 'A play order is missing a refund message!';
$_['lang_e_ajax_2']             = 'A play order is missing tracking info!';
$_['lang_e_ajax_3']             = 'An Amazon order is missing an "Other Carrier" entry!';
$_['lang_title_order_update']   = '批量訂單更新';
?>