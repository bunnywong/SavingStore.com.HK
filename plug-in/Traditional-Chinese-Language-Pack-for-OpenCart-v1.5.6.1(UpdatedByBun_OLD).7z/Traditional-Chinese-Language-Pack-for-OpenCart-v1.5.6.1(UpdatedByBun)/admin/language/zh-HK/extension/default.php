<?php
$_['lang_openbay_new']              = '創建新清單';
$_['lang_openbay_edit']             = '查看/編輯清單';
$_['lang_openbay_fix']              = '修正錯誤';
$_['lang_openbay_processing']       = '處理中';

$_['lang_amazonus_saved']           = 'Saved (not uploaded)';
$_['lang_amazon_saved']             = 'Saved (not uploaded)';
$_['lang_play_pending_new']         = 'Pending (new)';
$_['lang_play_pending_updated']     = 'Pending (updated)';
$_['lang_play_warning']             = 'Warning messages';
$_['lang_play_pending_delete']      = 'Pending delete';
$_['lang_play_stock_updating']      = 'Stock updating';

$_['lang_markets']                  = 'Markets';
$_['lang_bulk_btn']                 = 'eBay bulk upload';

$_['lang_marketplace']              = 'Marketplace';
$_['lang_status']                   = '狀態';
$_['lang_option']                   = 'Option';