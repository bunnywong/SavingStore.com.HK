<?php
// Heading 
$_['heading_title']    = '擴展功能模組管理';

// Text
$_['text_success']     = '已成功修改擴展功能模組管理';

// Error
$_['error_permission'] = '警告︰您沒有權限修改擴展功能模組管理設置';
$_['error_upload']     = '警告︰尚未選擇要上傳的文檔';
$_['error_filetype']   = '警告︰不支持的文檔類型';
?>