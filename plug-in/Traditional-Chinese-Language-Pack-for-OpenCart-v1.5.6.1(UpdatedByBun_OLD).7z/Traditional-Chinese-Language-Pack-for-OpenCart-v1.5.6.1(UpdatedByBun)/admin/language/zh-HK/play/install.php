<?php
$_['heading_title']                     = 'Play.com (歐洲)';
$_['text_edit']                         = '編輯';
$_['text_install']                      = '安裝';
$_['text_uninstall']                    = '卸載';
$_['text_enabled']                      = '啟用';
$_['text_disabled']                     = '停用';
$_['lang_text_success']                 = 'Play.com插件已經保存';
?>