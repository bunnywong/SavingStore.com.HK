<?php
$_['lang_cancel']                           = '取消訂單';
$_['lang_page_title']                       = '競爭對手的定價報告';
$_['lang_column_name']                      = 'Name';
$_['lang_column_dispatchto']                = 'Dispatch To';
$_['lang_column_price_uk']                  = '您的價格 (UK)';
$_['lang_column_price_cheap_uk']            = '最便宜的價格 (UK)';
$_['lang_column_price_euro']                = '您的價格 (Europe)';
$_['lang_column_price_cheap_euro']          = '最便宜的價格 (Europe)';
$_['lang_column_stock']                     = '庫存';
$_['lang_column_product_id']                = 'ID';
$_['lang_column_product_type']              = 'ID Type';
$_['lang_no_data_found']                    = '未發現價格數據';
$_['lang_created']                          = '報告創建︰';
?>