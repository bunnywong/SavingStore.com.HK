<?php
$_['lang_heading']                      = 'Play.com (�ڬw)';
?>