<?php
// Heading
$_['heading_title']    = '商戶信用';

// Text
$_['text_total']       = '訂單總計';
$_['text_success']     = '成功︰您已成功修改商戶信用！';

// Entry
$_['entry_status']     = '狀態︰';
$_['entry_sort_order'] = '排序︰';

// Error
$_['error_permission'] = '警告︰您沒有權限修改商戶信用！';
?>