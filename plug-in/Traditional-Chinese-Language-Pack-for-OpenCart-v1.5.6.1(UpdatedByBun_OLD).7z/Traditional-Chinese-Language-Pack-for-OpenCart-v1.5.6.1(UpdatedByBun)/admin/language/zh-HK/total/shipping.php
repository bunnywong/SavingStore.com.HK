<?php
// Heading
$_['heading_title']    = '貨運';

// Text
$_['text_total']       = '訂單總計';
$_['text_success']     = '成功︰ 您已成功更改了貨運方式！';

// Entry
$_['entry_estimator']  = '貨運預估︰';
$_['entry_status']     = '狀態︰';
$_['entry_sort_order'] = '排序︰';

// Error
$_['error_permission'] = '警告︰您沒有變更貨運設定的權限！';
?>