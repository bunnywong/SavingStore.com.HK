<?php
// Heading
$_['heading_title']    = '總計';

// Text
$_['text_total']       = '訂單總計';
$_['text_success']     = '成功︰ 您已成功修改訂單總計！';

// Entry
$_['entry_status']     = '狀態︰';
$_['entry_sort_order'] = '排序︰';

// Error
$_['error_permission'] = '警告︰ 您沒有變更總計的權限！';
?>
