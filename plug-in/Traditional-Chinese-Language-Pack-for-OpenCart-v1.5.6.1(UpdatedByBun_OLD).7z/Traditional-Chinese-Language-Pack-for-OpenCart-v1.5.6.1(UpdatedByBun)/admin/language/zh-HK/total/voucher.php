<?php
// Heading
$_['heading_title']    = '禮品券';

// Text
$_['text_total']       = '訂單金額';
$_['text_success']     = '成功︰ 您已成功修改禮品券！';

// Entry
$_['entry_status']     = '狀態︰';
$_['entry_sort_order'] = '排序︰';

// Error
$_['error_permission'] = '警告︰ 您沒有變更禮品券的權限！';
?>