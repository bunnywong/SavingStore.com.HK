<?php
$_['lang_title']                    = 'OpenBay Pro for Amazon US';
$_['lang_heading']                  = 'Amazon US Overview';
$_['lang_overview']                 = 'Amazon US Overview';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = '設置';
$_['lang_heading_account']          = '我的帳戶';
$_['lang_heading_links']            = '商品鏈接';
$_['lang_heading_register']         = '註冊';
$_['lang_heading_stock_updates']    = '庫存更新';
$_['lang_heading_saved_listings']   = 'Saved listings';