<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro for eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Stock report';
$_['lang_btn_return']                   = '返回';
$_['lang_report_label']                 = 'Email report';
$_['lang_report_btn']                   = 'Request';
$_['lang_ajax_load_error']               = '對不起，無法連接';
$_['lang_ajax_load_sent']               = '請求已發送';
