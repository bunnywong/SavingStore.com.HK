<?php
$_['lang_openbay']              = 'OpenBay Pro';
$_['lang_page_title']           = 'OpenBay Pro for eBay';
$_['lang_ebay']                 = 'eBay';
$_['lang_heading']              = 'Addons';
$_['lang_addon_desc']           = 'Addons are modules that are known to be supported or enhance the usability of OpenBay Pro.';
$_['lang_addon_name']           = 'Addon name';
$_['lang_addon_version']        = '版本';
$_['lang_addon_none']           = '你有沒有安裝的插件';
$_['lang_error_validation']     = 'You need to register for your API token and enable the module.';
$_['lang_btn_return']           = '返回';

