﻿~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
Last updated 20140301 - by FrEd 
Contact: fred@mimndforward.com
~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~

Traditional Chinese Language Pack for OpenCart v1.5.6.0 or v1.5.6.1 (繁體中文語言包)

Suitable for Hong Kong, Taiwan and other Traditional Chinese Language region

適用於香港、臺灣以及其他使用繁體中文地區

Change log:
1 Mar 2013 - Added for oc1.5.6.1
